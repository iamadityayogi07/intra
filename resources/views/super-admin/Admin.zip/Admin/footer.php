</main>


         </div>
      </div>

<?php include('header.php') ?>

<script src="./assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<script src="./assets/libs/simplebar/dist/simplebar.min.js"></script>

<!-- Theme JS -->
   <script src="./assets/js/theme.min.js"></script>
   <script src="./assets/libs/apexcharts/dist/apexcharts.min.js"></script>
   <script src="./assets/js/vendors/chart.js"></script>
   <script src="./assets/libs/quill/dist/quill.min.js"></script>
   <script src="./assets/js/vendors/editor.js"></script>
   <script src="./assets/libs/dropzone/dist/min/dropzone.min.js"></script>
   <script src="./assets/js/vendors/dropzone.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
    <script>
      $("#single").select2({
          placeholder: "Select Email",
          allowClear: true
      });
     
    </script>   
   </body>

</html>
